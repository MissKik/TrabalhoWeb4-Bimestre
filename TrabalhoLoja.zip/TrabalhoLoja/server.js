const express = require('express')
const session = require('express-session')
const bodyParser = require('body-parser');
const ClienteDAO = require('./src/controller/ClienteDAO');
const Cliente = require("./src/model/Cliente");
const DepartamentoDAO = require('./src/controller/DepartamentoDAO');
const ProdutoDAO = require('./src/controller/ProdutoDAO');
const Produto = require("./src/model/Produto")

const app = new express()

app.use(express.static(__dirname + '/public'));

app.use(bodyParser.urlencoded({ extended: true }))

app.set('view engine', 'ejs')
app.set('views', __dirname + "/src/view")

app.use(session({
    secret: 'TrabalhoBicoMateigaBabaSopa',
    resave: true,
    saveUninitialized: true
}));


app.get('/', function (req, res) {
    res.sendFile(__dirname + "/index.html")
})

app.get('/login.html', function(req, res) {
    res.sendFile(__dirname + '/public/template/login.html'); 
});

app.post('/login', async function (req, res) {
    let login = req.body.txtLogin
    let senha = req.body.txtSenha
    let dao = new ClienteDAO()
    let cliente = null
    try {

        cliente = await dao.login(login, senha)
        if (cliente != null) {
            req.session.usuario = cliente
            res.send(cliente.nome + " logado com sucesso.")
        }
        else {
            req.session.usuario = null
            res.send("Erro no login/senha")
        }
    }
    catch (erro) {
        console.log("Erro no login: " + erro)
    }
})

app.get('/cadastro.html', function(req, res) {
    res.sendFile(__dirname + '/public/template/cadastro.html');
});

app.post('/cadastro', async function (req, res) {
    const cliente = {
        nome: req.body.txtNome,
        login: req.body.txtLogin,
        senha: req.body.txtSenha 
    };

    const clienteDAO = new ClienteDAO();
    
    try {
        const codigo = await clienteDAO.gravar(cliente);
        res.send(`Cadastro realizado com sucesso!`);
    } catch (erro) {
        console.log(erro);
        res.send("Erro ao cadastrar o cliente.");
    }
});

app.get('/ListarDep', async function (req, res) {

    let dao = new DepartamentoDAO()
    let tabela = await dao.listar()
    res.render("departamento", { tabela })

})

app.get('/listarProduto/:codigo', async function (req, res) {
    try {
        let codigo = parseInt(req.params.codigo)
        let dao = new ProdutoDAO();
        let tabela = await dao.listar(codigo)
        res.render("produto", { tabela })
    } catch (erro) { console.log(erro) }
})

app.post('/comprar', function (req, res) {
    try {
        let obj = new Produto();
        obj.codigo = parseInt(req.body.txtCodigo);
        obj.descricao = String(req.body.txtDescricao);
        obj.preco = parseFloat(req.body.txtPreco); // Corrigido para parseFloat
        obj.qtde = parseInt(req.body.txtQtde);

        // Inicializa o carrinho se não existir
        if (!req.session.carrinho) {
            req.session.carrinho = []; // Inicializa como array vazio
        }

        // Verifica se o produto já existe no carrinho
        const index = req.session.carrinho.findIndex(item => item.codigo === obj.codigo);
        if (index > -1) {
            // Se já existir, atualiza a quantidade
            req.session.carrinho[index].qtde += obj.qtde;
        } else {
            // Se não existir, adiciona o novo produto ao carrinho
            req.session.carrinho.push(obj);
        }

        res.redirect("/mostrarCarrinho");
    } catch (erro) {
        console.log(erro);
    }
});

app.get("/mostrarCarrinho", function(req, res){
    try {
        let v = req.session.carrinho || []; 
        let s = "";
        
        for (let i = 0; i < v.length; i++) {
            s += v[i].descricao + " - R$: " + v[i].preco.toFixed(2) + " x " + v[i].qtde + "\n"; 
        }
        
        console.log(s); 
        res.send("Carrinho:\n" + s); 
    } catch (erro) {
        console.log(erro);
    }
});

app.post('/finalizarCompra', async (req, res) => {
    if (!req.session.usuario) { 
        return res.send("Você precisa estar logado para finalizar a compra. <a href='/login'>Login</a>");
    }

    const vendaDAO = new VendaDAO();
    const venda = {
        total: req.session.carrinho.reduce((acc, item) => acc + (item.preco * item.qtde), 0),
        codcli: req.session.usuario.codigo,
        itens: req.session.carrinho.map(item => ({
            qtde: item.qtde,
            precounit: item.preco,
            codproduto: item.codigo,
            codvenda: null 
        }))
    };

    try {
        const idVenda = await vendaDAO.gravar(venda);
        
        req.session.carrinho = [];
        
        res.send(`Compra finalizada com sucesso! ID da Venda: ${idVenda}`);
    } catch (erro) {
        console.log(erro);
        res.send("Erro ao finalizar a compra.");
    }
});


app.listen(3000, function (erro) {
    if (erro) {
        console.log("Erro no servidor: " + erro)
    }
    else {
        console.log("Servidor rodando na porta 3000")
    }
})