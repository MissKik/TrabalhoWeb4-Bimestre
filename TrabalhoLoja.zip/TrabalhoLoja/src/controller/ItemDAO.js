const Banco = require("../model/Banco");
const Item = require("../model/Item");

module.exports = class ItemDAO {
    async gravar(item) {
        try {
            Banco.init();
            await Banco.conexao.query(
                'INSERT INTO item(qtde, precounit, codproduto, codvenda) VALUES($1, $2, $3, $4)',
                [item.qtde, item.precounit, item.codproduto, item.codvenda]
            );
            Banco.conexao.end();
        } catch (erro) {
            console.log(erro);
            throw erro; // Propagar erro para o controlador
        }
    }
}