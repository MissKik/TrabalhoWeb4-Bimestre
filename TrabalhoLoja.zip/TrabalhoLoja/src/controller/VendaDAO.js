const Banco = require("../model/Banco");
const Venda = require("../model/Venda");
const ItemDAO = require("./itemDAO");

module.exports = class VendaDAO {
    async gravar(venda) {
        try {
            Banco.init();
            const resVenda = await Banco.conexao.query(
                'INSERT INTO venda(total, codcli) VALUES($1, $2) RETURNING codigo',
                [venda.total, venda.codcli]
            );

            const idVenda = resVenda.rows[0].codigo;

            const itemDAO = new ItemDAO();
            for (const item of venda.itens) {
                item.codvenda = idVenda; 
                await itemDAO.gravar(item);
            }

            Banco.conexao.end();
            return idVenda;
        } catch (erro) {
            console.log(erro);
            throw erro; 
        }
    }
}