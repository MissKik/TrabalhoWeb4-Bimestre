module.exports = class Cliente{
    codigo
    nome
    login
    senha

    #codigo
    #nome
    #login
    #senha
   constructor() {
        this.#codigo = 0
        this.#nome=""
        this.#login=""
        this.#senha=""
    }
    set codigo(c) {
        this.#codigo=c
    }
    get codigo() {
        return(this.#codigo)
    }
    set nome(n) {
        this.#nome=n
    }
    get nome() {
        return(this.#nome)
    }
    set login(l) {
        this.#login=l
    }
    get login() {
        return(this.#login)
    }
    set senha(s) {
        this.#senha=s
    }
    get senha() {
        return(this.#senha)
    }
}
//edita pra ficar bonitinho, igual o departamento