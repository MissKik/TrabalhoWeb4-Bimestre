module.exports = class Produto {
    #codigo
    #descricao
    #preco
    #qtde
    #imagem
    #coddep
    constructor() {
        this.#codigo = 0;
        this.#descricao = "";
        this.#preco = 0.0;
        this.#qtde = 0;
        this.#imagem = "";
        this.#coddep = null; 
    }
    set codigo(c) {
        this.#codigo=c
    }
    get codigo() {
        return(this.#codigo)
    }
    set descricao(d) {
        this.#descricao=d
    }
    get descricao() {
        return(this.#descricao)
    }
    set preco(p) {
        this.#preco=p
    }
    get preco() {
        return(this.#preco)
    }
    set qtde(q) {
        this.#qtde=q
    }
    get qtde() {
        return(this.#qtde)
    }
    set imagem(i) {
        this.#imagem=i
    }
    get imagem() {
        return(this.#imagem)
    }
    set coddep(cd) {
        this.#coddep=cd
    }
    get coddep() {
        return(this.#coddep)
    }
}