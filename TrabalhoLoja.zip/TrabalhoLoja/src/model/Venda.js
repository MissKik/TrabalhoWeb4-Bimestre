module.exports = class Venda {
    #codigo
    #total
    #datav
    #codcli
    constructor() {
        this.#codigo = 0;
        this.#total = 0;
        this.#datav = new Date();
        this.#codcli = null; 
    }
    set codigo(c) {
        this.#codigo=c
    }
    get codigo() {
        return(this.#codigo)
    }
    set total(t) {
        this.#total=t
    }
    get total() {
        return(this.#total)
    }
    set datav(d) {
        this.#datav=d
    }
    get datav() {
        return(this.#datav)
    }
    set codcli(cc) {
        this.#codcli=cc
    }
    get codcli() {
        return(this.#codcli)
    }
}